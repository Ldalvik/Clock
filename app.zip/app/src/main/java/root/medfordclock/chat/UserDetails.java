package root.medfordclock.chat;

public class UserDetails {
    static String username = "";
    static String password = "";
    static String chatWith = "";
}
